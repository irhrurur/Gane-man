# VEILBREAK — Vanguard Operations

An original browser FPS and operations hub, built with Next.js App Router, Three.js, PostgreSQL and Drizzle. Original generated campaign/mode artwork, original story, geometric battlefields and weapon models, and synthesized Web Audio effects.

## Play

Open the preview and choose **Deploy to Campaign** or **Enter Training Grounds**. The deployment briefing explains controls. Click **Deploy Now** to enter the battlefield. A desktop browser with WebGL2, keyboard, and mouse is recommended. Low graphics quality is available for integrated GPUs. Pointer lock has a click-and-drag fallback.

- WASD / arrow keys: move
- Mouse: look; left button: fire; right button: aim
- Shift: sprint; Shift + C: slide
- C / Ctrl: crouch; Space: jump / mantle low cover
- R: reload; 1 / 2 / Tab: switch primary and sidearm
- E (hold): interact, recover cores, or revive downed AI allies
- Q: equipped ability; G: forward frag detonation; F: melee
- B: buy survival supplies for 500 score
- Escape: pause

## Implemented content

- 16 individually briefed, replayable campaign operations across city, industrial, desert, laboratory, forest, snow, and horror-themed environments. Reusable encounter systems support elimination, infiltration, capture/extraction, defense, escort, sabotage, and bosses. Final campaign operation offers two story outcomes.
- 11 offline arena rules: team deathmatch, free-for-all, domination, hardpoint, Blackwire sabotage, core capture, Echo Confirmed collection, Arsenal Run, gunfight, infection, and headquarters.
- AI-supported survival with two squadmates, reviving, pickups, score-funded upgrades, boss waves, difficulty choices, wave limits and endless play.
- Solo horror survival with melee hunters, resource pickups, no passive health regeneration, hidden intel, and boss waves.
- Live-fire range and six training/challenge configurations.
- Seven weapon definitions, six abilities, primary/sidearm switching, damage/headshots, recoil, reloads, ammunition, impact effects, destructible cover, armor, grenades, and melee.
- Attachments affect magazine capacity, damage, accuracy, movement, ADS zoom, or visible weapon geometry. Armory imagery is a Sentinel-platform illustration; the equipped weapon is constructed in 3D when deployed.
- Enemy state logic includes patrol/search, advance, flanking, strafing, retreat, line-of-sight fire and reinforcements. Rifle, flanker, heavy, shield, sniper, elite, drone, hunter and sentinel variants. Offline free-for-all bots can engage one another.
- Career XP, levels, rank roadmap, reward-bearing challenges, campaign completion, match history, callsign editing, career export and persistent survival leaderboards.
- Automatically saved audio, graphics, sensitivity and accessibility settings. Local profile cache when the career service is unavailable.

## Scope notes

This is a functional browser-scale interpretation of a much larger game brief, not a claim of AAA production scale. Campaign operations are compact procedural encounters built on shared systems, not 16 hand-authored multi-hour levels. Multiplayer is explicitly offline bots, and co-op uses AI squadmates rather than live online players. Cinematics use illustrated story panels and in-game radio text. Character geometry and animation are procedural; there are no motion-captured faces, recorded voice performances, fully simulated vehicles, or arbitrary building destruction. Mobile navigation is responsive; full FPS play is best on desktop.

Career and leaderboards use a local PostgreSQL database. An HTTP-only cookie identifies an anonymous operator. Rewards are calculated server-side, but local match results are not anti-cheat-verified. This is not a competitive online service.

## Project layout

- `src/components/CommandCenter.tsx`: operations hub, menus, settings, career UI
- `src/components/Game.tsx`: briefing, HUD, pause, results and ending choice
- `src/game/engine.ts`: Three.js world, physics, combat, AI, objectives, lifecycle
- `src/game/content.ts`: missions, modes, weapons, abilities, challenges
- `src/game/rules.ts`: match completion and career reward rules
- `src/game/audio.ts`: original synthesized effects and music pulse
- `src/db/schema.ts`: operators and match records
- `src/app/api/profile`: profile, loadout, rewards, claims and history
- `src/app/api/leaderboard`: persistent survival rankings

## Validation

- `node tests/engine.cjs`: 98 assertions covering all campaign/arena completion conditions, reachable objective locations, raycast damage/headshots, reload/ammo conservation, abilities, sliding, survival escalation/bosses, supplies, and reviving. It uses real Three.js geometry/math with a mocked renderer and deterministic objective simulations, not a human playthrough.
- `node tests/browser.cjs`: running-server Playwright checks for menus, mission/ruleset selectors, database-backed loadout persistence, settings, actual WebGL firing/reload/ability/pause, and mobile overflow. Requires Playwright Chromium and system dependencies. Screenshots are written to `/tmp/veilbreak-*.png`.
- `npx next typegen`
- `npm exec tsc -- --noEmit --pretty false`
- `npm run build`

Database connection comes from `DATABASE_URL`. Apply tables with `npx drizzle-kit push` after database initialization. No external game API credentials are required.
